package com.example.tubespbm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
